package com.mycompany.app.event_organization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventOrganizationApplicationTests {

	@Test
	void contextLoads() {
	}

}
